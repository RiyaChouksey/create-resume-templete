document.getElementById('upload-pic').addEventListener('change', function(event) {
    const reader = new FileReader();
    reader.onload = function() {
        const imgElement = document.getElementById('profile-pic');
        imgElement.src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
});


document.getElementById('upload-pic').addEventListener('change', function(event) {
    const reader = new FileReader();
    reader.onload = function() {
        const imgElement = document.getElementById('profile-pic');
        imgElement.src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
});

document.getElementById('add-skill').addEventListener('click', function() {
    const newSkill = document.getElementById('new-skill').value;
    if (newSkill) {
        const skillList = document.getElementById('skills');
        const newSkillItem = document.createElement('li');
        newSkillItem.textContent = newSkill;
        skillList.appendChild(newSkillItem);
        document.getElementById('new-skill').value = '';
    }
});

function printPage() {
    window.print();
}